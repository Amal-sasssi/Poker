#ifndef _ELIMINE_CARTE_HPP_
#define _ELIMINE_CARTE_HPP_

#include <iostream>
#include <time.h>
#include <string>
#include "poker_hand.hpp"


int Elimine_carte(std::string strategie, CARTE Carte[5], int b)
{
  // Principe : Se débarasser d'une carte qui n'est pas compatible avec notre stratégie.
  // On a un joueur avec une stratégie et un jeu. // A quoi correspond "int b" ?
  CARTE carte_elimine; // Déclarer mais pas utiliser !
  int a=1; // Pourquoi a = 1 ? Pour initialiser la condition du "if" dans la boucle du peureux ?
  int i;
  int c_coeur=0;
  int c_pique=0;
  int c_trefle =0;
  int c_carreaux =0;
  if(strategie=="autiste")
  {
    a=rand()%5; // Je comprends ici que l'autiste élimine n'importe quelle carte.
  }
  if(strategie=="peureux") // Soit le peureux se débarasse de sa carte la + faible, soit il se débarasse d'une carte dont la
                          // couleur est différente des autres.
                          // Que devra-t-il faire s'il se trouve dans la configuration suivante, s'il veut gagner :
                          // configuration : valeur : |     2     |      2     |      9      |      valet     |     Roi     |
                          //               : couleur :|   coeur   |    pique   |    carreau  |      trefle    |     pique   |
                          // Se débarassera-t-il de son 2 (dans l'espoir de gagner), même s'il s'agit d'une paire ? Si c'est le cas,
                          // Il risque de perdre une PAIRE. Quelqu'un de prudent(=peureux) ne ferait pas une chose pareille... 
  {
    if(b==0)
    {
      for(i=0;i<5;i++)
      {
        if(a>=Carte[i].valeur && Carte[i].valeur>0)  //On elimine la plus petite valeur ->>> Condition bizarre puisque l'on a initialisé a = 1 !!?
       {
          a=i;
        }
      }

      for( i =0; i<5 ;++i) //On essaye de voir si on a au moins 3 ou 4 cartes meme couleur pour nous debarasser de cette carte
          {
              if( Carte[i].couleur == 0) {c_coeur ++;}
              if( Carte[i].couleur == 1) {c_carreaux ++;}
              if( Carte[i].couleur == 2) {c_trefle ++;}
              if( Carte[i].couleur == 3) {c_pique ++;}
          }

      if(c_coeur == 4 || c_coeur==3)
      {
        for(i=0;i<5;i++)
        {
          if(Carte[i].couleur != 0)
          {
            a=i;

          }
        }
      }
      if(c_pique == 4 || c_pique==3)
      {
        for(i=0;i<5;i++)
        {
          if(Carte[i].couleur != 3)
          {
            a=i;

          }
        }
      }
      if(c_trefle ==4 || c_trefle==3)
      {
        for(i=0;i<5;i++)
        {
          if(Carte[i].couleur != 2)
          {
            a=i;

          }
        }
      }
      if(c_carreaux ==4 || c_carreaux ==3)
      {
        for(i=0;i<5;i++)
        {
          if(Carte[i].couleur != 1)
          {
            a=i;

          }
        }
      }


    }
  }
  return a; // la valeur de la carte qu'on essaie d'éliminer ??
}
#endif
